package Exceptions;

public class InputException extends Exception {
	
	   public InputException(String errMsg) 
	   {
	      super(errMsg); 
	      
	      System.out.println("Error message is: " + errMsg +"\n");
	  } 
	   

}
