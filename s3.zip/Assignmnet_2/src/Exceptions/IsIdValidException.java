package Exceptions;

public class IsIdValidException extends Exception {
	
public IsIdValidException(String errMsg) {
	super(errMsg); 
   
    System.out.println("Error message is: " + errMsg);
	} 
}

