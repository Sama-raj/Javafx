package Exceptions;

public class RentException extends Exception {

public RentException(String msg) {

	super(msg);    

    System.out.println("Error message is: " + msg);
}
}
