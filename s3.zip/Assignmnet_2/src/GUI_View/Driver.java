package GUI_View;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import Rental_db_Model.*;
import Exceptions.DatabaseException;
import Exceptions.InputException;
import Rental_db_Model.CreateTable;
import Rental_db_Model.Database_Property;
import Rental_system.others_Controller.FlexiRentSystem;
import Rental_system.others_Controller.Rental_property;
import Rental_system.others_Controller.Rental_records;
import file_management.FileOperation;
import javafx.application.Application;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javafx.util.Callback;

public class Driver extends Application {
	int index=0;

	
private TableView<Property> table = new TableView<Property>();
	
    private final ObservableList<Property> data =
        FXCollections.observableArrayList();
    
   private TextField filterField;
	
   ArrayList<Rental_property> base_data =  new ArrayList<Rental_property>();
   
	public static void main(String[] args) throws SQLException, FileNotFoundException, ClassNotFoundException, DatabaseException {

		ConnectionTest.connect();
		 launch(args);


    }

   	public void start(Stage primaryStage) throws ClassNotFoundException, FileNotFoundException, DatabaseException, InputException 
    {
   	 ArrayList<Rental_property> s=Database_Property.getRecords();
		base_data = s;
   		for(int i=0;i<base_data.size();i++)
   		{
   			data.add(new Property(base_data.get(i)));
   		}
   		primaryStage.setTitle("Flexi Rent System");
    	
    	BorderPane border = new BorderPane();
    	    	 
         MenuItem menuItem1 = new MenuItem("Import List");
         MenuItem menuItem2 = new MenuItem("Export List");
         MenuItem menuItem3 = new MenuItem("Quit");
         
         HBox head = new HBox();
         Button B = new Button("Refresh");
         head.getChildren().add(B);
         
         B.setOnAction(new EventHandler<ActionEvent>() 
         {
             @Override public void handle(ActionEvent event)
             {
            	 
				try {
					base_data = FlexiRentSystem.display_property();
				} catch (ClassNotFoundException | FileNotFoundException | InputException | DatabaseException e) {
					
				}
            		
            		for(int i=0;i<base_data.size();i++)
            		{
            			data.add(new Property(base_data.get(i)));
            		}
             }
         });
         
         FileChooser fileChooser = new FileChooser();
         fileChooser.setTitle("Open Resource File");
         
         menuItem1.setOnAction(new EventHandler<ActionEvent>() {
	    	 
 	        @Override
 	        public void handle(ActionEvent event) {
 	        	
 	        	fileChooser.getExtensionFilters().addAll(
 	        	         new ExtensionFilter("Text Files", "*.txt"));

 	        	        File selectedFile = fileChooser.showOpenDialog(primaryStage);
 	        	        if (selectedFile != null) {
 	        	        	try {
								FileOperation.readfileproperty(selectedFile);
							} catch (FileNotFoundException e) {
								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("Information Dialog");
								alert.setHeaderText("File Not found");
								alert.setContentText("Couldnot import!");
							}
 	        	        }
 	        }
 	    });


         menuItem2.setOnAction(new EventHandler<ActionEvent>() {
	    	 
 	        @Override
 	        public void handle(ActionEvent event) {

              
		         DirectoryChooser dir = new  DirectoryChooser();
	 	           String selectedDirectory = null;
				File file = new File(selectedDirectory + "/" + "Rc.txt");

              //  File file = dir.showDialog(primaryStage);
 	        	dir.setInitialDirectory(file);
	                if (file != null) {
	                	try {
	                	ArrayList<Rental_property> prop_data = FlexiRentSystem.getpropertylist();    	
 	        	
 	        	for(int i=0;i<prop_data.size();i++)
 	        	{
 	        		
						FileOperation.writefileproperty(base_data,"rc.txt");
						
 	        	}
 	        	}catch (FileNotFoundException | ClassNotFoundException | DatabaseException | InputException e) {
						Alert alert2 = new Alert(AlertType.INFORMATION);
						alert2.setTitle("Information Dialog");
						alert2.setHeaderText("File Not found");
						alert2.setContentText("Couldnot export!");
					}
 	        	}
 	       
 	        	}
 	        	
 	    });
         
         menuItem3.setOnAction(e -> primaryStage.hide());
         
                     
         MenuButton menuButton = new MenuButton("Options", null, menuItem1, menuItem2, menuItem3); 
         Scene scene = new Scene(border, 1000, 1000);
             
         
         HBox hbox = new HBox(menuButton);
         border.setTop(hbox);
         
         final Label label = new Label("Property List");
         label.setFont(new Font("Arial", 20));

         final Label actionTaken = new Label();

         table.setEditable(true);
         
         FilteredList<Property> filteredData = new FilteredList<>(data, p -> true);

         TableColumn Type = new TableColumn("Type");
         Type.setMinWidth(100);
         Type.setCellValueFactory(
                 new PropertyValueFactory<Property, String>("Type"));

         TableColumn Status = new TableColumn("Status");
         Status.setMinWidth(100);
         Status.setCellValueFactory(
                 new PropertyValueFactory<Property, String>("Status"));

         TableColumn Suburb = new TableColumn("Suburb");
         Suburb.setMinWidth(100);
         Suburb.setCellValueFactory(
                 new PropertyValueFactory<Property, String>("Suburb"));
         
         TableColumn Rooms = new TableColumn("Rooms");
         Rooms.setMinWidth(100);
         Rooms.setCellValueFactory(
                 new PropertyValueFactory<Property, String>("Rooms"));

        

         TableColumn<Property, Property> btnCol = new TableColumn<>("Images");
         btnCol.setMinWidth(300);
         btnCol.setCellValueFactory(new Callback<CellDataFeatures<Property, Property>, ObservableValue<Property>>() {
           @Override public ObservableValue<Property> call(CellDataFeatures<Property, Property> features) {
               return new ReadOnlyObjectWrapper(features.getValue());
           }
         });
         btnCol.setComparator(new Comparator<Property>() {
           @Override public int compare(Property p1, Property p2) {
             return p1.getID().compareTo(p2.getID());
           }
         });
         btnCol.setCellFactory(new Callback<TableColumn<Property, Property>, TableCell<Property, Property>>() {
           @Override public TableCell<Property, Property> call(TableColumn<Property, Property> btnCol) {
             return new TableCell<Property, Property>() {
  	        	Image im = new Image("file:/../images/prop0.jpg");

                ImageView buttonGraphic = new ImageView(im);
                 
               
               final Button button = new Button(); {
            	   buttonGraphic.setFitHeight(150);
            	   buttonGraphic.setImage(im);
            	
                 buttonGraphic.setFitWidth(150);
                 button.setGraphic(buttonGraphic);
                 button.setMinWidth(130);
                 
               }
               @Override public void updateItem(final Property p, boolean empty) {
                 super.updateItem(p, empty);
                 String z="Click me";
                 if (p != null) {
                     button.setText(z);


                 
                       File file = new File(p.getImage_file());
                    
					Image DisplayImage = new Image("file:images/prop"+index%15+".jpg");
					index++;
                       buttonGraphic.setImage(DisplayImage);
                       Stage secondaryStage =  new Stage();
                   setGraphic(button);
                   button.setOnAction(new EventHandler<ActionEvent>() {
                     @Override public void handle(ActionEvent event) {
                       actionTaken.setText("Selected " + p.getID());
                       Stage2 s = new Stage2();
                   	Scene scene = null;
					try {
						scene = s.add_view(p.getID(),secondaryStage);
					} 
					catch (Exception e) {
						
						
					}
                   	Stage secondaryStage =  new Stage();
                      	secondaryStage.setScene(scene);
                   	secondaryStage.setTitle("Property Details view");
                       secondaryStage.show();

                       }
                   });
                 } else {
                   setGraphic(null);
                 }
               }
             };
           }
         });

         
           
 		
 		// 3. Wrap the FilteredList in a SortedList. 
 		SortedList<Property> sortedData = new SortedList<>(filteredData);
 		
 		// 4. Bind the SortedList comparator to the TableView comparator.
 		// 	  Otherwise, sorting the TableView would have no effect.
 		sortedData.comparatorProperty().bind(table.comparatorProperty());
 		
 		// 5. Add sorted (and filtered) data to the table.
 		table.setItems(filteredData);
         
         
         
 		 
         table.getColumns().addAll(Type, Status,Suburb, Rooms, btnCol);
         table.setPrefSize( 700, 800 );
         
         
         ChoiceBox<String> choiceBox = new ChoiceBox();
         choiceBox.getItems().addAll("Type", "Status", "Subub","Rooms");
         choiceBox.setValue("First Name");

         TextField textField = new TextField();
         textField.setPromptText("Search here!");
         textField.setOnKeyReleased(keyEvent ->
         {
             switch (choiceBox.getValue())//Switch on choiceBox value
             {
                 case "Type":
                     filteredData.setPredicate(p -> p.getType().toLowerCase().contains(textField.getText().toLowerCase().trim()));//filter table by first name
                     break;
                 case "Status":
                     filteredData.setPredicate(p -> p.getStatus().toLowerCase().contains(textField.getText().toLowerCase().trim()));//filter table by first name
                     break;
                 case "Suburb":
                     filteredData.setPredicate(p -> p.getSuburb().toLowerCase().contains(textField.getText().toLowerCase().trim()));//filter table by first name
                     break;
                 case "Rooms":
                     filteredData.setPredicate(p -> p.getRooms().toLowerCase().contains(textField.getText().toLowerCase().trim()));//filter table by first name
                     break;
             }
         });

         choiceBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) ->
         {//reset table and textfield when new choice is selected
             if (newVal != null)
             {
                 textField.setText("");
                 filteredData.setPredicate(p->true);//This is same as saying flPerson.setPredicate(p->true);
             }
         });
         HBox h = new HBox();
         h.getChildren().addAll(choiceBox,textField);
         h.setAlignment(Pos.CENTER);
         
         

         final VBox vbox = new VBox();
         vbox.setSpacing(5);
         vbox.setPadding(new Insets(10, 10, 10, 10));
         vbox.getChildren().addAll(label, head,table, actionTaken,h);
         VBox.setVgrow(table, Priority.ALWAYS);
         
         border.setCenter(vbox);
         
         primaryStage.setScene(scene);
         primaryStage.show();
         	
    }
   	public  static class Property {

        private SimpleStringProperty Type;
        private SimpleStringProperty Status;
        private SimpleStringProperty Suburb;
        private SimpleStringProperty Rooms;
        private SimpleStringProperty ID;
        private String image_file;

        public Property(Rental_property P) {
            this.Type = new SimpleStringProperty(P.getPropertyType());
            this.Status = new SimpleStringProperty(P.getPropertyStatus());
            this.Suburb = new SimpleStringProperty(P.getSuburb());
            int nr = P.getNumberOfBedroom();
            String s= String.valueOf(nr);
            this.Rooms = new SimpleStringProperty(s);
            this.ID = new SimpleStringProperty(P.getPropertyId());
            this.image_file = P.getImage();
        }

        public String getType() {
            return Type.get();
        }

        
        public String getStatus() {
            return Status.get();
        }

        
        public String getSuburb() {
            return Suburb.get();
        }

        
        public String getRooms() {
            return Rooms.get();
        }

        public String getID() {
            return ID.get();
        }
        
        public String getImage_file() {
            return image_file;
        }

        
    }
}
