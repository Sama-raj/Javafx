package GUI_View;

import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Exceptions.DatabaseException;
import Exceptions.InputException;
import Exceptions.PerformMaintenanceException;
import Exceptions.RentException;
import Exceptions.ReturnException;
import GUI_View.Rent.Layout_new;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.FlexiRentSystem;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Maintain {
	
	Stage window;
	Scene scene;

	public Scene add_view(String s){
	
		Layout_new l = new Layout_new();
        
	    BorderPane border = new BorderPane();
	    
	    border.setCenter(l.property_detail(s));
	    
	    scene = new Scene(border, 600, 300);
	    
	    MenuItem menuItem1 = new MenuItem("Back");
	    
	    MenuButton menuButton = new MenuButton("Options", null, menuItem1);
	    
	    menuItem1.setOnAction(new EventHandler<ActionEvent>() {
	    	 
	        @Override
	        public void handle(ActionEvent event) {
//	        	((Node)(event.getSource())).getScene().getWindow().hide();
	        	Stage secondaryStage =  new Stage();
	        	Stage2 B = new Stage2();
	         	Scene scene = null;
				try {
					scene = B.add_view(s,secondaryStage);
				} catch (ClassNotFoundException | FileNotFoundException | DatabaseException | InputException e) {
					
				}
	         	
	            	secondaryStage.setScene(scene);
	         	secondaryStage.setTitle("Property Details view");
	             secondaryStage.show();
	        }
	    });

	    
	    HBox hbox = new HBox(menuButton);
	    border.setTop(hbox);
	    
	    return scene;
	    
	    
	}

	public class Layout_new{
		
//		private DateTime dateset;
		private String d;

	public VBox property_detail(String s) {
		


        HBox h1 = new HBox();
//        HBox h2 = new HBox();
        HBox h3 = new HBox();
        
        
        
        Button submit = new Button("Submit");
        Button clear = new Button("Clear");
        

        h3.getChildren().addAll(submit,clear);
        
        final Label label = new Label();
        
        submit.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	    public void handle(ActionEvent e) {
        	        
        	            
        	            try {
							FlexiRentSystem.maintain(s);
						} catch (NumberFormatException | InputException | PerformMaintenanceException e1) {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Information Dialog");
							alert.setHeaderText("ReturnException");
							alert.setContentText("Property couldnot be assigned for Maintennace!");

							alert.showAndWait();
							
						}
        	        
        	        }
        	     }
        	 );
        	 
        	//Setting an action for the Clear button
        	clear.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	    public void handle(ActionEvent e) {
        	       
        	        label.setText(null);
        	    }
        	});
        
	    VBox layout = new VBox();
	    
	    
	    layout.getChildren().addAll(h3,label);

	    return layout;
	}
	}
	
	    
	}

