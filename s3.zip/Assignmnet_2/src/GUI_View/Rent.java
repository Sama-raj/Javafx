package GUI_View;

import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Exceptions.DatabaseException;
import Exceptions.InputException;
import Exceptions.RentException;
import GUI_View.Stage2.Layout_new;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.FlexiRentSystem;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Rent {
	
	Stage window;
	Scene scene;

	public Scene add_view(String s){
	   
	    	    	    	        	    
	    Layout_new l = new Layout_new();
        
	    BorderPane border = new BorderPane();
	    
	    border.setCenter(l.property_detail(s));
	    
	    scene = new Scene(border, 600, 300);
	    
	    MenuItem menuItem1 = new MenuItem("Back");
	    
	    MenuButton menuButton = new MenuButton("Options", null, menuItem1);
	    
	    menuItem1.setOnAction(new EventHandler<ActionEvent>() {
	    	 
	        @Override
	        public void handle(ActionEvent event) {
	        	Stage secondaryStage =  new Stage();
	        	Stage2 B = new Stage2();
	         	Scene scene = null;
				try {
					scene = B.add_view(s,secondaryStage);
				} catch (ClassNotFoundException | FileNotFoundException | DatabaseException | InputException e) {
					
				}
	         	
	            	secondaryStage.setScene(scene);
	         	secondaryStage.setTitle("Property Details view");
	             secondaryStage.show();
	             
	        }
	    });

	    
	    HBox hbox = new HBox(menuButton);
	    border.setTop(hbox);
	    
	    return scene;
	    
	    
	}

	public class Layout_new{
		
		private String d;

	public VBox property_detail(String s) {
		
		DatePicker rentdate = new DatePicker();
		
		
		rentdate.setValue(LocalDate.now());
		
		Label l1 = new Label();
		
		rentdate.setOnAction(event -> {
		    LocalDate date = rentdate.getValue();
		    d = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		    l1.setText(d);
		});
        


        HBox h1 = new HBox();
        HBox h3 = new HBox();
        
        TextField t1 = new TextField ();
        TextField t2 = new TextField ();
        
        Button submit = new Button("Submit");
        Button clear = new Button("Clear");
        
        t1.setPromptText("Enter Customer Id");
        t1.setPrefColumnCount(10);
        t1.getText();
        
        t2.setPromptText("Enter Number of days");
        t2.setPrefColumnCount(10);
        t2.getText();
        
        h1.getChildren().addAll(rentdate,l1);
        h3.getChildren().addAll(submit,clear);
        
        final Label label = new Label();
        
        submit.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	    public void handle(ActionEvent e) {
        	        if ((t1.getText() != null && !t2.getText().isEmpty())) {
        	            label.setText(t1.getText() + " " + t2.getText() + ", "
        	                + "thank you for info!");
        	            
        	            try {
							FlexiRentSystem.rent(s, t1.getText(),d , Integer.parseInt(t2.getText()));
						} catch (RentException e1) {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Information Dialog");
							alert.setHeaderText("Rent Exception");
							alert.setContentText("Property Could not be Rented!");

							alert.showAndWait();
							
						}
        				catch( NumberFormatException | ClassNotFoundException | InputException | DatabaseException e1)
        				{
        					
        				}
        	        } else {
        	            label.setText("You have not entered details.");
        	        }
        	     }
        	 });
        	 
        	clear.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	    public void handle(ActionEvent e) {
        	        t1.clear();
        	        t2.clear();
        	        label.setText(null);
        	    }
        	});
        
	    VBox layout = new VBox();
	    
	    
	    layout.getChildren().addAll(t1,h1,t2,h3,label);

	    return layout;
	}
	}
	

	    
	}


