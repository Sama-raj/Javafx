package GUI_View;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import Exceptions.DatabaseException;
import Exceptions.InputException;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.FlexiRentSystem;
import Rental_system.others_Controller.Rental_property;
import Rental_system.others_Controller.Rental_records;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Stage2  {

Stage window;
Scene scene;

public Scene add_view(String s,Stage stage) throws ClassNotFoundException, FileNotFoundException, DatabaseException, InputException{
    
    Layout_new l = new Layout_new();
            
    BorderPane border = new BorderPane();
    
    border.setCenter(l.property_detail(s));
    
    scene = new Scene(border, 600, 300);
    
    MenuItem menuItem1 = new MenuItem("Back");
    
    MenuButton menuButton = new MenuButton("Options", null, menuItem1);
    
    
        	menuItem1.setOnAction(e -> stage.hide());
    

    
    HBox hbox = new HBox(menuButton);
    border.setTop(hbox);
    
    return scene;
    
}

public class Layout_new{
	
	private TableView<Record> table = new TableView<Record>();
    private final ObservableList<Record> data =
        FXCollections.observableArrayList();
    private int id;
           

public VBox property_detail(String s) throws ClassNotFoundException, FileNotFoundException, DatabaseException, InputException {
	
	ArrayList<Rental_property> prop_data = FlexiRentSystem.getpropertylist();
	
	
	for(int i=0;i<prop_data.size();i++)
	{
		if(prop_data.get(i).getPropertyId().equals(s))
			id=i;
		
	}
	
	ArrayList<Rental_records> base_data = FlexiRentSystem.display_record(prop_data.get(id));
		
		for(int i=0;i<base_data.size();i++)
		{
			data.add(new Record(base_data.get(i)));
		}
	
	
	TableColumn ID = new TableColumn("ID");
    ID.setMinWidth(100);
    ID.setCellValueFactory(
            new PropertyValueFactory<Record, String>("ID"));

    TableColumn Startdate = new TableColumn("Startdate");
    Startdate.setMinWidth(100);
    Startdate.setCellValueFactory(
            new PropertyValueFactory<Record, String>("Startdate"));

    TableColumn Returndate = new TableColumn("Returndate");
    Returndate.setMinWidth(200);
    Returndate.setCellValueFactory(
            new PropertyValueFactory<Record, String>("Returndate"));
    
    TableColumn Fee = new TableColumn("Fee");
    Fee.setMinWidth(200);
    Fee.setCellValueFactory(
            new PropertyValueFactory<Record, String>("Fee"));
    
    TableColumn LateFee = new TableColumn("LateFee");
    LateFee.setMinWidth(200);
    LateFee.setCellValueFactory(
            new PropertyValueFactory<Record, String>("LateFee"));
    
    table.setItems(data);
     
    table.getColumns().addAll(ID,Startdate,Returndate,Fee,LateFee);
	
	Button b1 = new Button();
    b1.setText("Rent");
    Button b2 = new Button();
    b2.setText("Return");
    Button b3 = new Button();
    b3.setText("Perform Maintenance");
    Button b4 = new Button();
    b4.setText("Complete Maintennace");

    final Label actionTaken = new Label();
    
    b1.setOnAction(new EventHandler<ActionEvent>() 
    {
        @Override public void handle(ActionEvent event)
        {
          actionTaken.setText("Rent");
          Rent s = new Rent();
         	Scene scene = s.add_view(prop_data.get(id).getPropertyId());
         	Stage secondaryStage =  new Stage();
            	secondaryStage.setScene(scene);
         	secondaryStage.setTitle("Scene Switch Sample");
             secondaryStage.show();
        }
    });
    b2.setOnAction(new EventHandler<ActionEvent>() 
    {
        @Override public void handle(ActionEvent event)
        {
          actionTaken.setText("Return");
          Return s = new Return();
       	Scene scene = s.add_view(prop_data.get(id).getPropertyId());
       	Stage secondaryStage =  new Stage();
          	secondaryStage.setScene(scene);
       	secondaryStage.setTitle("Scene Switch Sample");
           secondaryStage.show();
        }
    });
    b3.setOnAction(new EventHandler<ActionEvent>() 
    {
        @Override public void handle(ActionEvent event)
        {
          actionTaken.setText("Perform Maintenance");
          Maintain s = new Maintain();
         	Scene scene = s.add_view(prop_data.get(id).getPropertyId());
         	Stage secondaryStage =  new Stage();
            	secondaryStage.setScene(scene);
         	secondaryStage.setTitle("Scene Switch Sample");
             secondaryStage.show();
        }
    });
    b4.setOnAction(new EventHandler<ActionEvent>() 
    {
        @Override public void handle(ActionEvent event)
        {
          actionTaken.setText("Complete Maintenance");
          Finish s = new Finish();
         	Scene scene = s.add_view(prop_data.get(id).getPropertyId());
         	Stage secondaryStage =  new Stage();
            	secondaryStage.setScene(scene);
         	secondaryStage.setTitle("Scene Switch Sample");
             secondaryStage.show();
        }
    });
    HBox h1 = new HBox();
    HBox h2 = new HBox();
    Label label2 = new Label("Description:"+prop_data.get(id).getdesc());
    label2.setStyle("-fx-text-fill: darkblue; -fx-font-size: 16px; "
            + "-fx-effect: dropshadow(gaussian, aqua, 2, 0.1, 1, 1);");
    h1.getChildren().addAll(b1,b2,b3,b4);
    h2.getChildren().add(label2);
    VBox layout = new VBox();
    final Label label = new Label("Rental Records");
    label.setFont(new Font("Arial", 20));
    
    layout.getChildren().addAll(label,h2,table,h1, actionTaken);

    return layout;
}
}

public  static class Record {

    private SimpleStringProperty ID;
    private SimpleStringProperty Startdate;
    private SimpleStringProperty Returndate;
    private SimpleStringProperty Fee;
    private SimpleStringProperty LateFee;
    

    public Record(Rental_records R) {
        this.ID = new SimpleStringProperty(R.getRecordId());
        this.Startdate = new SimpleStringProperty(R.getStartDate().toString());
        this.Returndate = new SimpleStringProperty(R.getReturnDate().toString());
        float f1 = R.getRentalFee();
        String s1= String.valueOf(f1);
        float f2 = R.getLateFee();
        String s2= String.valueOf(f2);
        this.Fee = new SimpleStringProperty(s1);
        this.LateFee= new SimpleStringProperty(s2);
        
    }

    public String getFee() {
        return Fee.get();
    }

    
    public String getLateFee() {
        return LateFee.get();
    }

    
    public String getStartdate() {
        return Startdate.get();
    }

    
    public String getReturndate() {
        return Returndate.get();
    }

    public String getID() {
        return ID.get();
    }
    
   

    
}


}