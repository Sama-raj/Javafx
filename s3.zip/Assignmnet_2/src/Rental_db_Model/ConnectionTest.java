package Rental_db_Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionTest {
	
//	public static void main(String args[])
//	{
//		connect();
//	}
	
	public static void connect() {
		
		final String DB_NAME = "Rental_DB";
		
		//use try-with-resources Statement
		try (Connection con = getConnection(DB_NAME)) {
			
			System.out.println("Connection to database " + DB_NAME + " created successfully");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static Connection getConnection(String dbName) 
					throws SQLException, ClassNotFoundException {
		//Registering the HSQLDB JDBC driver
		Class.forName("org.hsqldb.jdbc.JDBCDriver");
			
		
		Connection con = DriverManager.getConnection
				("jdbc:hsqldb:file:Database/" + dbName, "SA", "");
		return con;
	}
}
