package Rental_db_Model;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable {
//	public static void main(String args[]) throws SQLException
//	{
//		create();
//	}
	public static void create() throws SQLException {
//		ConnectionTest.connect();
		final String DB_NAME = "Rental_DB";
		final String TABLE_NAME1 = "PROPERTY";
		final String TABLE_NAME2 = "RECORDS";
		int result1, result2;
		//use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
			result1 = stmt.executeUpdate("DROP TABLE IF EXISTS RECORDS;");
			result1 = stmt.executeUpdate("DROP TABLE IF EXISTS PROPERTY;");
			result1 = stmt.executeUpdate("CREATE TABLE PROPERTY (" + 
					"	ID varchar(10) NOT NULL,"+
					"	STREETNUMBER INTEGER NOT NULL," + 
					"	STREETNAME varchar(40) NOT NULL," + 
					"	SUBURB varchar(40) NOT NULL," + 
					"	NUMBER_OF_ROOMS INTEGER NOT NULL," + 
					"	PROPERTY_TYPE varchar(20) NOT NULL," + 
					"	PROPERTY_STATUS varchar(20) NOT NULL," + 
					"   LAST_MAINTENANCE varchar(10) NOT NULL,"+
					"   IMAGE varchar(10) NOT NULL,"+
					"   DESC char(300) NOT NULL,"+
					"  PRIMARY KEY (ID));"
		);
			
			result2 = stmt.executeUpdate("CREATE TABLE RECORDS (" + 
					"	RECORDID varchar(10) NOT NULL," + 
					"	STARTDATE varchar(10) NOT NULL," + 
					"	EST_RETURNDATE varchar(10) NOT NULL," + 
					"	RETURNDATE varchar(10) NOT NULL," + 
					"	FEE FLOAT ," + 
					"	LATE_FEE FLOAT," + 
					"  	PRIMARY KEY (RECORDID)," + 
					"	FOREIGN KEY (ID) REFERENCES PROPERTY);"
					
		);
			if(result1 == 0) {
				System.out.println("Table " + TABLE_NAME1 + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME1 + " is not created");
			}
			
			if(result2 == 0) {
				System.out.println("Table " + TABLE_NAME2 + " has been created successfully");
			} else {
				System.out.println("Table " + TABLE_NAME2 + " is not created");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

