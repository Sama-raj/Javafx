package Rental_db_Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import Rental_system.others_Controller.*;
import Exceptions.DatabaseException;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.Premium_suite;
import Rental_system.others_Controller.Rental_property;

public class Database_Property  {
	
	private final static String DB_NAME = "Rental_DB";
	private static ConnectionTest T;
	private static DateTime getdate(String s)
	{
		int dd,mm,yyyy;
		DateTime date;
		
		dd = Integer.parseInt(s.substring(0, 2));
		mm = Integer.parseInt(s.substring(3, 5));
		yyyy = Integer.parseInt(s.substring(6, 10));
		date = new DateTime(dd,mm,yyyy);
		
		return date;
	}
	
	public static ArrayList<Rental_property> getRecords() throws DatabaseException, ClassNotFoundException {
		String sql = "SELECT * FROM PROPERTY";
		ArrayList<Rental_property> record = new ArrayList<Rental_property>();
		Rental_property P;
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {try (ResultSet rs = stmt.executeQuery(sql))
			{
			while (rs.next()) {
				String Id = rs.getString("ID");
				int streetno = rs.getInt("STREETNUMBER");
				String streetname = rs.getString("STREETNAME");
				String suburb = rs.getString("SUBURB");
				int numberofroom = rs.getInt("NUMBER_OF_ROOMS");
				String prop_type = rs.getString("PROPERTY_TYPE");
				String  prop_status = rs.getString("PROPERTY_STATUS");
				String date_info =rs.getString("LAST_MAINTENANCE");
				String image=rs.getString("IMAGE");
				String desc=rs.getString("DESC");

				DateTime date;
				date =getdate(date_info);
				if(prop_type.toLowerCase()=="apartment")
				{
					P = new Apartment(Id,streetno,streetname,suburb,numberofroom,prop_type);
					P.setdesc(desc);
					P.setimage(image);
					//P.setlmdate(s);
				}else {
					P = new Premium_suite(Id,streetno,streetname,suburb,numberofroom,prop_type,date);
					P.setdesc(desc);
					P.setimage(image);
				}record.add(P);
			}
			if (record.size() == 0) {
				throw new DatabaseException("No records in database");
			}
			
		} catch (Exception e) {
			throw new DatabaseException("Couldn't get records out of database "+e.getMessage());
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
	}
		return record;
	}

	public static void insert(Rental_property P) throws DatabaseException, ClassNotFoundException {
		DateTime D;
		String Id = P.getPropertyId();
		int streetno = P.getStreetNumber();
		String streetname = P.getStreetName();
		String suburb = P.getSuburb();
		int numberofroom = P.getNumberOfBedroom();
		String prop_type = P.getPropertyType();
		String  prop_status = P.getPropertyStatus();
		String date_info =P.getLMdate().toString();
		String image =P.getImage();
		String desc =P.getdesc();

		

		String sql = "INSERT INTO PROPERTY VALUES ('"+Id+"',"+streetno+",'"+streetname+"','"+suburb+"',"+numberofroom+",'"+prop_type+"','"+prop_status+"','"+date_info+
				"','"+image +"','"+desc +"')";	
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			int r=stmt.executeUpdate(sql);
			
			con.commit();
			System.out.println("Insert into table  executed successfully");
			System.out.println(r + " row(s) affected");

            
        } catch (Exception e) {
			throw new DatabaseException("Couldn't insert " + P.getPropertyId() +" into database " + e.getMessage());
        }
	}
	
	public static void update(Rental_property P) throws DatabaseException, ClassNotFoundException {
		String sql = "UPDATE PROPERTY SET PROPERTY_STATUS ='"+P.getPropertyStatus()+"',LAST_MAINTENENACE = '"+P.getLMdate().toString()+"' WHERE RECORDID = '"+P.getPropertyId()+"'";
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		)  {
			
            stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			throw new DatabaseException("Couldn't update " + P.getPropertyId() + " in database " + e.getMessage());
		}
	}

	public static void delete(Rental_property P) throws DatabaseException, ClassNotFoundException {
		String sql = "DELETE FROM PROPERTY WHERE ID = '"+P.getPropertyId()+"'";
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		)  {
			
            stmt.executeUpdate(sql);
		} catch (Exception e) {
			throw new DatabaseException("Couldn't delete " + P.getPropertyId()+ " in database " + e.getMessage());
		}
	}

	
}



