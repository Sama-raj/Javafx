package Rental_db_Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

import Exceptions.DatabaseException;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.Rental_records;

public class Database_Records {
	
	private final static String DB_NAME = "Rental_DB";
	private static ConnectionTest T;
	private static DateTime getdate(String s)
	{
		int dd,mm,yyyy;
		DateTime date;
		
		dd = Integer.parseInt(s.substring(0, 2));
		mm = Integer.parseInt(s.substring(3, 5));
		yyyy = Integer.parseInt(s.substring(6, 10));
		date = new DateTime(dd,mm,yyyy);
		
		return date;
	}
	
	public static ArrayList<Rental_records> getRecords() throws DatabaseException, ClassNotFoundException {
		String sql = "SELECT * FROM RECORDS";
		ArrayList<Rental_records> record = new ArrayList<Rental_records>();
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		)  {
			
			try(ResultSet rs = stmt.executeQuery(sql))
			{
			while (rs.next()) {
				String Prop_Id = rs.getString("ID");
				String Cust_Id = rs.getString("CUST_ID");
				String Record_Id = rs.getString("RECORDID");
				String startdate = rs.getString("STARTDATE");
				String est_returndate = rs.getString("EST_RETURNDATE");
				String returndate = rs.getString("RETURNDATE");
				float  fee = rs.getFloat("FEE");
				float late_fee =rs.getFloat("LATE_FEE");
				DateTime start_date,return_date,estreturn_date;
				start_date =getdate(startdate);
				return_date =getdate(returndate);
				estreturn_date=getdate(est_returndate);
				int rentdays = DateTime.diffDays(estreturn_date, start_date);
				Rental_records R = new Rental_records(Prop_Id,Cust_Id,start_date,rentdays);	
				R.setLateFee(late_fee);
				R.setRentalFee(fee);
				record.add(R);
			}
			if (record.size() == 0) {
				throw new DatabaseException("No items in database");
			}
			
		} catch (Exception e) {
			throw new DatabaseException("Couldn't get items out of database "+e.getMessage());
		}}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return record;
	}

	public static void insert(Rental_records R) throws DatabaseException, ClassNotFoundException {
		DateTime D;
		String Prop_Id = R.getID();
		String Cust_Id = R.getCustId();
		String Record_Id = R.getRecordId();
		String startdate = R.getStartDate().toString();
		String est_returndate = R.getEstimatedReturnDate().toString();
		String returndate = R.getReturnDate().toString();
		float  fee = R.getRentalFee();
		float late_fee =R.getLateFee();
		
		String sql = "INSERT INTO RECORDS VALUES ('"+Prop_Id+"','"+Cust_Id+"','"+Record_Id+"','"+startdate+"','"+est_returndate+"','"+returndate+"',"+fee+","+late_fee+")";	
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		)  {
			
            stmt.executeUpdate(sql);
            con.commit();
        } catch (Exception e) {
			throw new DatabaseException("Couldn't insert " + R.getRecordId() +" into database " + e.getMessage());
        }
	}
	
	public static void update(Rental_records R) throws DatabaseException, ClassNotFoundException {
		String sql = "UPDATE RECORDS SET FEE ="+R.getRentalFee()+",LATE_FEE = "+
	R.getLateFee()+",RETURNDATE = '"+R.getReturnDate().toString()+"'  WHERE RECORDID = '"+R.getRecordId()+"'";
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		)  {
			
            stmt.executeUpdate(sql);
			
		} catch (Exception e) {
			throw new DatabaseException("Couldn't update " + R.getRecordId() + " in database " + e.getMessage());
		}
	}

	public static void delete(Rental_records R) throws DatabaseException, ClassNotFoundException {
		String sql = "DELETE FROM RECORDS WHERE RECORDID = '"+R.getRecordId()+"'";
		try (Connection con = ConnectionTest.getConnection(DB_NAME);
				Statement stmt = con.createStatement();
		) {
			
            stmt.executeUpdate(sql);
		} catch (Exception e) {
			throw new DatabaseException("Couldn't delete " + R.getRecordId()+ " in database " + e.getMessage());
		}
	}

	
}
