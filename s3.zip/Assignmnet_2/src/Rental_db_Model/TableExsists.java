package Rental_db_Model;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TableExsists  {
	public static void main(String[] args) throws SQLException {

		final String DB_NAME = "Rental_DB";

		// IMPORTANT: table name is uppercase
		final String TABLE_NAME2 = "RECORDS";
		final String TABLE_NAME1 = "PROPERTY";
		
		// use try-with-resources Statement
		try (Connection con = ConnectionTest.getConnection(DB_NAME)) {

			DatabaseMetaData dbm = con.getMetaData();
			ResultSet tables1 = dbm.getTables(null, null, TABLE_NAME1.toUpperCase(), null);
			ResultSet tables2 = dbm.getTables(null, null, TABLE_NAME2.toUpperCase(), null);
			
			if(tables1 != null) {
				if (tables1.next()) {
					System.out.println("Table " + TABLE_NAME1 + " exists.");
				}
				else {
					System.out.println("Table " + TABLE_NAME1 + " does not exist.");
				}	
				tables1.close();
			} else {
				System.out.println(("Problem with retrieving database metadata"));
			}
				if(tables2 != null) {
					if (tables2.next()) {
						System.out.println("Table " + TABLE_NAME2 + " exists.");
					}
					else {
						System.out.println("Table " + TABLE_NAME2 + " does not exist.");
					}	
					tables2.close();
				} else {
					System.out.println(("Problem with retrieving database metadata"));}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}