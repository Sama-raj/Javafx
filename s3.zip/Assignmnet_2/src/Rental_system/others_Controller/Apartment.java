package Rental_system.others_Controller;

import java.util.ArrayList;
import java.util.Calendar;

import Exceptions.DatabaseException;
import Exceptions.PerformMaintenanceException;
import Exceptions.RentException;
import Exceptions.ReturnException;
import Rental_db_Model.Database_Property;
import Rental_db_Model.Database_Records;

public class Apartment extends Rental_property {

	private float rate1,rate2,rate3;
	private float laterate;
	private DateTime new_maintenance;
	
	
	public Apartment(String id,int no, String sn, String s,int n,String pt)
	{
		super(id,no,sn,s,n,pt);
		rate1 = 143;
		rate2 = 210;
		rate3 = 319;
		laterate = (float) 1.115;
		
	}
	public void rent(String customerId, DateTime rentDate, int numOfRentDay) throws ClassNotFoundException, DatabaseException, RentException
	{
		int i,j=0;
		boolean return_val = true;
		
		String s,Id;int dd,mm,yyyy;
		DateTime currentdate,enddate;
			
		enddate = new DateTime(rentDate,numOfRentDay);
		
		currentdate = getCurrentDate();
		
		s = rentDate.getFormattedDate();
				
		dd = Integer.parseInt(s.substring(0, 2));
		mm = Integer.parseInt(s.substring(3,5));
		yyyy = Integer.parseInt(s.substring(6, 10));

		Calendar calendar = Calendar.getInstance();
		calendar.set(yyyy, mm, dd);
        int weekDay = calendar.get(Calendar.DAY_OF_WEEK);//checking for min days based on day of week
               
        if(weekDay >= Calendar.SUNDAY && weekDay <= Calendar.THURSDAY)
        {
        	
        	if (numOfRentDay<2)
        		return_val =false;
        }
        if(weekDay == Calendar.SATURDAY || weekDay == Calendar.FRIDAY)
        {
        	if (numOfRentDay<3)
        		return_val = false;
        }
		
		if(numOfRentDay > 28)
			return_val =false;
		
		if(DateTime.diffDays(currentdate, rentDate)> 0)
			return_val = false;
	
		j=Record_size();
		for(i=0;i<j;i++)
		{	
			if(DateTime.diffDays(rentDate, Record_item(i).getStartDate())==0)
				return_val = false;
			else if (DateTime.diffDays(Record_item(i).getEstimatedReturnDate(),rentDate) >= 0)
				return_val = false;
			else if (new_maintenance!=null&&((DateTime.diffDays(enddate,new_maintenance)>=0)&&(DateTime.diffDays(new_maintenance,rentDate)>=0)))
				return_val = false;
			else
				return_val = true;
		}	
								
		if(return_val)
		
		{
			
			Id = getPropertyId();
			
			Rental_records R = new Rental_records(Id,customerId, rentDate,numOfRentDay);

			Record_add(R);
			setPropertyStatus("Rented");
			
			Database_Records.insert(R);
//			Database_Property.update(this);
			
		}
		else
		{
			throw new RentException("Cannot be Rented");
		}
				
	}
	public void returnProperty(DateTime returnDate) throws ReturnException, ClassNotFoundException, DatabaseException
	{
		int days,extra,j;
		float charge = 0;
				
		DateTime currentdate = getCurrentDate();
		j=Record_size();
		
		boolean return_val=true;
				
		if(new_maintenance!=null)
				if(DateTime.diffDays(returnDate,new_maintenance)==0)
					return_val=false;
		if(DateTime.diffDays(returnDate,currentdate)<0)
				return_val=false;
		if(DateTime.diffDays(returnDate,Record_item(j-1).getStartDate())<0)
			return_val=false;
		
		if(return_val)
		{
			Record_item(j-1).setReturnDate(returnDate);
			days = DateTime.diffDays(returnDate,Record_item(j-1).getStartDate());
			extra = DateTime.diffDays(Record_item(j-1).getReturnDate(),Record_item(j-1).getEstimatedReturnDate());
			switch(getNumberOfBedroom())
			{
			case 1: charge=rate1;
						break;
			case 2:	charge=rate2;
						break;
			case 3:	charge=rate3;
						break;
			}
		if(extra>0)
			{
			
			Record_item(j-1).setRentalFee(charge*days);
			Record_item(j-1).setLateFee(extra*laterate*charge);
			}
		else
			{
			Record_item(j-1).setRentalFee(charge*days);
			}
			
		setPropertyStatus("Available");
		
		Database_Records.update(Record_item(j-1));
//		Database_Property.update(this);
		
		}
		else
			throw new ReturnException("Cannot be returned");
		
	}
	
	public void performMaintenance() throws PerformMaintenanceException, ClassNotFoundException, DatabaseException
	{
		Boolean return_val1 = true;
		DateTime currentdate,date; int j;
		
		currentdate = getCurrentDate();
		new_maintenance=currentdate;		
		
		if(getPropertyStatus().equals("Rented"))
		{
			j=Record_size();
			date = Record_item(j-1).getReturnDate();
			if(DateTime.diffDays(date, currentdate)> 0)
				return_val1 = false;	
		}
		if(return_val1)
		{
			setPropertyStatus("Under maintenance");
			new_maintenance = currentdate;
			completeMaintenance(currentdate);
//			Database_Property.update(this);
			
		}
		else
			throw new PerformMaintenanceException("Cannot Perform Maintenance");
		
	}
		public void completeMaintenance(DateTime completionDate)
		{
			setPropertyStatus("completed");
			System.out.println("Completed");
			
		}
		public String getDetails() {
		  	  String output = super.toString();
		  	  
		  	  return output;
		  	 }
		public DateTime getLMdate()
		{
			DateTime currentdate;
			currentdate = getCurrentDate();
			return currentdate;
			
		}

}
