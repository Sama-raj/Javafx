package Rental_system.others_Controller;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import file_management.FileOperation;
import java.util.Scanner;

import Exceptions.CompleteMaintenanceException;
import Exceptions.DatabaseException;
import Exceptions.InputException;
import Exceptions.PerformMaintenanceException;
import Exceptions.RentException;
import Exceptions.ReturnException;
import Rental_db_Model.Database_Property;
import Rental_db_Model.Database_Records;
import file_management.FileOperation;

public class FlexiRentSystem {
	
	private static ArrayList<Rental_property> RP;
	private static ArrayList<Rental_records> RR;
		
	
	public FlexiRentSystem() throws SQLException
	{
		RP = new ArrayList<Rental_property>();
		RR = new ArrayList<Rental_records>();
		
	}
	
	// Adding a pre-stored list of Rental_proerties for the first time
	public static ArrayList<Rental_property>  add_property_firstrun() throws InputException, ClassNotFoundException, DatabaseException, FileNotFoundException
	{
		/* Read from RentalProperty text file and write to database at startup*/
		RP = FileOperation.readfileproperty_firstrun();
		for(int i=0;i<RP.size();i++)
		{
			//System.out.println(RP.get(i).toString());
			Database_Property.insert(RP.get(i));
		}
		//read from database to display
		RP = Database_Property.getRecords();


		 return RP;
	}
	static void add_records() throws InputException, ClassNotFoundException, DatabaseException, FileNotFoundException
	{
//		Read records from file and write to database
		RR = FileOperation.readfilerecords();
		for(int i=0;i<RR.size();i++)
		{
			System.out.println(RR.get(i).toString());
			Database_Records.insert(RR.get(i));
		}
	}
	public static  ArrayList<Rental_property> add_property() throws InputException, ClassNotFoundException, DatabaseException, FileNotFoundException
	{
//		Read records from file and write to database
		File file = new File("RentalProperty_1.txt");
		RP = FileOperation.readfileproperty(file);
		for(int i=0;i<RP.size();i++)
		{
			System.out.println(RP.get(i).toString());
			Database_Property.insert(RP.get(i));
			
		}
		RP = Database_Property.getRecords();
		return RP;
	}
	


		public static void rent(String pid,String cid,String date,int n) throws InputException, ClassNotFoundException, DatabaseException, RentException
		{
			int i=0;
			i=RP.size();
			
			DateTime startdate;
			startdate = getdate(date);
			
			int id = 0;
			
			for (int j=0; j<i;j++)
			{
				if(RP.get(j).getPropertyId().equals(pid))
					{	
					id = j;
					}
				
			}
			try {
				RP.get(id).rent(cid,startdate,n);
				
			}catch(Exception e)
			{
				throw new RentException("Could not rent");
			}
					
		}
		
		public static void release(String pid,String date)throws InputException, ReturnException
		{
			int i=0;
			i=RP.size();
			DateTime enddate;
			int Id = 0;	
			
			for(int j=0;j<i;j++)
			{
				
			if(pid.equals(RP.get(j).getPropertyId()))
					{
						Id=j;
					}					
			}
			try
			{
			if(RP.get(Id).Record_size()==-1)
			{
			}
			}
				
			catch(Exception e)
			{
				throw new InputException( "User input invalid");
			}
			
			enddate = getdate(date);
			try
			{
			RP.get(Id).returnProperty(enddate);
			}
			catch(Exception e)
			{
				throw new ReturnException("Cannot be returned");
			}
		}
		public static void maintain(String pid) throws InputException, PerformMaintenanceException
		{
			int i;
			i=RP.size();
			int id=0;
			
			for (int j=0; j<i;j++)
				if(RP.get(j).getPropertyId().equals(pid))
					id = j;
			try
			{
			RP.get(id).performMaintenance();
			Database_Property.update(RP.get(id));
			}
			catch(Exception e)
			{
				throw new PerformMaintenanceException("cannot perform maintenance");
			}
			
		}
		public static void maintain_release(String pid, String date) throws InputException, CompleteMaintenanceException, ClassNotFoundException, DatabaseException
		{

			int i,id=0;
			i =	RP.size();
			DateTime maintaindate;
					
			for (int j=0; j<i;j++)
			{
				if(RP.get(j).getPropertyId().equals(pid))
					id = j;
			}
			if(RP.get(id) instanceof Premium_suite)
			{
				maintaindate = getdate(date);
			}
			else
				maintaindate= getCurrentDate();
			RP.get(id).completeMaintenance(maintaindate);
			
			
		}
		public static DateTime getdate(String s)
		{
			int dd,mm,yyyy;
			DateTime date;
			
			dd = Integer.parseInt(s.substring(0, 2));
			mm = Integer.parseInt(s.substring(3, 5));
			yyyy = Integer.parseInt(s.substring(6, 10));
			date = new DateTime(dd,mm,yyyy);
			
			return date;
		}
	 static DateTime getCurrentDate()//method to get current time
	    {
	    DateTime currentdate; String s;
	    int dd,mm,yyyy;
		s = DateTime.getCurrentTime();
				
		dd = Integer.parseInt(s.substring(8, 10));
		mm = Integer.parseInt(s.substring(5, 7));
		yyyy = Integer.parseInt(s.substring(0, 4));
		currentdate = new DateTime(dd,mm,yyyy);
		
		return currentdate;
	    }
	 
	 public static ArrayList<Rental_property> display_property() throws ClassNotFoundException, DatabaseException, FileNotFoundException, InputException
	 {
		 //get records and write to file
		 updatedatabase();
		 ArrayList<Rental_property> P = new ArrayList<Rental_property>();
		 P = Database_Property.getRecords();

		 return P;
		 
	 }
	 
	 public static ArrayList<Rental_property> getpropertylist() throws ClassNotFoundException, DatabaseException, FileNotFoundException, InputException
	 {
		 //diaplay(read) property only
		 ArrayList<Rental_property> P = new ArrayList<Rental_property>();
		 P = Database_Property.getRecords();
		 return P;
		 
	 }
	 public static ArrayList<Rental_records> getrecordlist() throws ClassNotFoundException, DatabaseException, FileNotFoundException, InputException
	 {
		 //diaplay(read) records only
		 ArrayList<Rental_records> P = new ArrayList<Rental_records>();
		 P = Database_Records.getRecords();
		 return P;
		 
	 }
	 
	 public static ArrayList<Rental_records> display_record(Rental_property P) throws ClassNotFoundException, DatabaseException, FileNotFoundException, InputException
	 {
		 //get records and write to file
		 ArrayList<Rental_records> R = new ArrayList<Rental_records>();
		 R = Database_Records.getRecords();

		 return R;
		 
	 }
	 public static  void updatedatabase() throws ClassNotFoundException, DatabaseException
	 {for(int i=0;i<RP.size();i++)
	 	{
		 Database_Property.insert(RP.get(i));
	 	}
		 
	 }

public static void setproperties(ArrayList<Rental_property> p) {
	// TODO Auto-generated method stub
	RP = p;
}
	
		
				
}
