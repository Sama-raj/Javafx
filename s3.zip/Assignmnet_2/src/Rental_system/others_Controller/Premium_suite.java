package Rental_system.others_Controller;

import Exceptions.CompleteMaintenanceException;
import Exceptions.DatabaseException;
import Exceptions.PerformMaintenanceException;
import Exceptions.RentException;
import Exceptions.ReturnException;
import Rental_db_Model.Database_Property;
import Rental_db_Model.Database_Records;

public class Premium_suite extends Rental_property

{
	private DateTime last_maintenance;
	private DateTime new_maintenance;
	private float rate, laterate;
	
	public Premium_suite(String id,int no, String sn, String s,int n,String pt, DateTime date)
	{
		super(id,no,sn,s,n,pt);
		
		rate = 554;
		laterate = 662;
		last_maintenance = date;
		new_maintenance =  new DateTime(date,10);
	}
	
	public  void rent(String customerId, DateTime rentDate, int numOfRentDay) throws ClassNotFoundException, DatabaseException, RentException
	{
		int i,j=0;
		boolean return_val = true;
		
		String Id;
		
		DateTime currentdate,enddate;
		
		enddate = new DateTime(rentDate,numOfRentDay);
		
		currentdate = getCurrentDate();
				
		if(DateTime.diffDays(currentdate, rentDate)> 0)//check with current date
			return_val = false;
		
		j=Record_size();
		for(i=0;i<j;i++)
		{	
			if(DateTime.diffDays(rentDate, Record_item(i).getStartDate())==0)
				return_val = false;
			else if (DateTime.diffDays(Record_item(i).getEstimatedReturnDate(),rentDate) >= 0)
				return_val = false;
			else if (new_maintenance!=null&&((DateTime.diffDays(enddate,new_maintenance)>=0)&&(DateTime.diffDays(new_maintenance,rentDate)>=0)))
				return_val = false;
			else
				return_val = true;
		}	
								
		if(return_val)
		{
			Id =getPropertyId();
			Rental_records R = new Rental_records(Id,customerId, rentDate,numOfRentDay);
			Record_add(R);
			Database_Records.insert(R);
			
			setPropertyStatus("Rented");
			
			
		}
		else
		{
			throw new RentException("Cannot be Rented");
		}
		
			
	}
	public void returnProperty(DateTime returnDate) throws ReturnException, ClassNotFoundException, DatabaseException
	{
		int days,extra,j;
					
		DateTime currentdate;
			
		currentdate = getCurrentDate();
				
		boolean return_val=true;
		
		j=Record_size();
		
		if(DateTime.diffDays(returnDate,new_maintenance)==0)
				return_val=false;
		if(DateTime.diffDays(returnDate,currentdate)<0)
				return_val=false;
		if(DateTime.diffDays(returnDate,Record_item(j-1).getStartDate())<0)
				return_val=false;
		
		if(return_val)
		{
			Record_item(j-1).setReturnDate(returnDate);
			days = DateTime.diffDays(returnDate,Record_item(j-1).getStartDate());
			extra = DateTime.diffDays(Record_item(j-1).getReturnDate(),Record_item(j-1).getEstimatedReturnDate());
			
			Record_item(j-1).setRentalFee(rate*days);
			if(extra>0)
			{
				Record_item(j-1).setLateFee(extra*laterate);
			}
							
			setPropertyStatus("Available");
			Database_Records.update(Record_item(j-1));
//			Database_Property.update(this);
				
		}
		else
			throw new ReturnException("Cannot be returned");
		
							
	}
	public void performMaintenance() throws PerformMaintenanceException// assign current date as maintenance date
, ClassNotFoundException, DatabaseException
	{
		Boolean return_val = true;
		DateTime currentdate,date;int j;
		currentdate = getCurrentDate();
				
		if(DateTime.diffDays(last_maintenance, currentdate)>10)
		{
			System.out.println("Maintenance over due\n");
		}
		if(getPropertyStatus().equals("Rented"))
		{
			j=Record_size();
			date = Record_item(j-1).getReturnDate();
			if(DateTime.diffDays(date, currentdate)> 0)
				return_val = false;
				
		}
		if(return_val)
		{
			setPropertyStatus("Under maintenance");
			new_maintenance=currentdate;
//			Database_Property.update(this);
		}
		else
			throw new PerformMaintenanceException("Cannot Perform Maintenance");
		
	}
	public void completeMaintenance(DateTime completionDate) throws CompleteMaintenanceException, ClassNotFoundException, DatabaseException
	{
		Boolean return_val = true;
		DateTime currentdate; 
		
		currentdate = getCurrentDate();
				
		if(DateTime.diffDays(currentdate, completionDate) > 0)
			return_val = false;
		else if(DateTime.diffDays(new_maintenance, completionDate)< 0)
			return_val = false;
		else
			return_val = true;
						
		if(return_val)
		{
			setPropertyStatus("Available");
			
			last_maintenance = completionDate;
//			Database_Property.update(this);
			
		}
		else
			throw new CompleteMaintenanceException("Cannot complete maintenance");	
		}
	
	
	public String getDetails() {
  	  String output = super.toString();
  	  output = output+":"+last_maintenance;
  	  return output;
  	 }
	
	public DateTime getLMdate()
	{
		return last_maintenance;
		
	}
  
	}
