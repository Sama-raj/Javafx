package Rental_system.others_Controller;

import java.io.Serializable;
import java.util.ArrayList;

import Exceptions.CompleteMaintenanceException;
import Exceptions.DatabaseException;
import Exceptions.PerformMaintenanceException;
import Exceptions.RentException;
import Exceptions.ReturnException;

import javafx.scene.image.Image;

abstract public class Rental_property implements Serializable  {
	 private static final Object[] Rental_records = null;

	private Rental_records[] rr = new Rental_records[100];

	private String Id;
	private int Street_number;
	private String Street_name;
	private String Suburb;
	private int No_of_rooms;
	private String Property_type; //FlexiRent currently has two types of rental properties; Apartment and Premium Suite
	private String Property_status; //inspect this attribute to determine whether the property is currently available for rent or being rented or under maintenance
	private ArrayList<Rental_records> R;
	private String Prop_image;
	private String desc;
	
	public Rental_property(String Id,int no, String sn, String s,int n,String pt)
	{
		this.Id = Id;
		Street_number = no;
		Street_name = new String(sn);
		Suburb = new String(s);
		No_of_rooms = n;
		Property_type = new String(pt);
		Property_status = new String("Available");
		R = new ArrayList<Rental_records>();
			
	}
	public abstract void rent(String customerId, DateTime rentDate, int numOfRentDay) throws ClassNotFoundException, DatabaseException, RentException;
	
	public abstract void returnProperty(DateTime returnDate)throws ReturnException, ClassNotFoundException, DatabaseException;
	
	public abstract void performMaintenance()throws PerformMaintenanceException, ClassNotFoundException, DatabaseException;
	
	public abstract void completeMaintenance(DateTime date) throws CompleteMaintenanceException, ClassNotFoundException, DatabaseException; 
	
	
	public String getPropertyId()
	{
        return Id;
    }

    public int getStreetNumber() {
        return Street_number;
    }
    
    public String getStreetName() 
    {
        return Street_name;
    }
    
    public String getSuburb() 
    {
        return Suburb;
    }

    public int getNumberOfBedroom() 
    {
        return No_of_rooms;
    }
    
    public String getPropertyType()
    {
        return Property_type;
    }
    
    public void setPropertyStatus(String s)
    {
        Property_status = new String(s);
    }
     
    public String getPropertyStatus()
    {
        return Property_status;
    }
        
    public static DateTime getCurrentDate()//method to get current time
    {
    DateTime currentdate; String s;
    int dd,mm,yyyy;
	s = DateTime.getCurrentTime();
			
	dd = Integer.parseInt(s.substring(8, 10));
	mm = Integer.parseInt(s.substring(5, 7));
	yyyy = Integer.parseInt(s.substring(0, 4));
	currentdate = new DateTime(dd,mm,yyyy);
	
	return currentdate;
    }
    public String toString() {
    	  String output = Id + ":" + Street_number + ":" + Street_name + ":" + Suburb + ":" + Property_type+ ":" + No_of_rooms + ":" + Property_status+":"+Id+".jpg" ;
    	  return output;
    	 }
    public  String getDetails()
    {
    	String s = toString();
    	return s;
    }
    public int Record_size()
    {	if(R == null)
    	return -1;
    	else
    	return R.size();
    }
    public Rental_records Record_item(int i)
    {
    	return R.get(i);
    }
    public void Record_add(Rental_records r)
    {
    	R.add(r);
    }
    public void addNewRentalRecord(Rental_records r) {
    	  //Array of 10 rental records
    	  shiftRecordByOne();

//    	  Rental_records[] rental_records = null;
    	  Rental_records[0] =r;
    	  int rentalRecordIndex=0;
		if (rentalRecordIndex != 10) {
    	   rentalRecordIndex++;
    	  }
    	 }

    	 private void shiftRecordByOne() {
    	  for (int i = 9; i >= 0; i--) {
    		  Rental_records [i + 1] = Rental_records [i];
    	  }
    	 }
    public ArrayList<Rental_records> Record_list()
    {
    	return R;
    }
    public void setdesc(String desc)
    {
  	  this.desc=desc;	 

    }
     
    public String getdesc()
    {
        return desc;
    }
    public String getImage()
    {
        return Prop_image;
    }
	public abstract DateTime getLMdate();
	public void setimage()
	
    {
        Prop_image = "image not available";
    }
	 public void setimage(String image) {
		 this.Prop_image=image;
		  }
	 public void setlmdate(String s)
	    {
	        s= null;
	    }
    
}
