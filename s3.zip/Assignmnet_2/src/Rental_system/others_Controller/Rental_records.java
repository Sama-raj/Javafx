package Rental_system.others_Controller;

import java.io.Serializable;




public class Rental_records implements Serializable{
	
	private String Record_Id;
	private String ID;
	private String Cust_Id;
	private DateTime startdate;
	private DateTime est_returndate;
	private DateTime returndate;
	private float fee;
	private float late_fee;
	
	public Rental_records(String pid,String customerId, DateTime rentDate, int numOfRentDay)
	{
		
		Record_Id = pid+"_"+customerId;
		Cust_Id = customerId;
		ID=pid;
		startdate = rentDate;
		est_returndate = new DateTime(startdate,numOfRentDay);
		returndate = est_returndate;
		fee = (float) 0.0;
		late_fee = (float) 0.0;
	}
	public Rental_records(String rid, DateTime rentDate, int numOfRentDay)
	{
		
		Record_Id = rid;
		
		startdate = rentDate;
		est_returndate = new DateTime(startdate,numOfRentDay);
		returndate = est_returndate;
		fee = (float) 0.0;
		late_fee = (float) 0.0;
	}

			
	public String getRecordId()
    {
        return Record_Id;
    }
	public String getCustId()
    {
        return Cust_Id;
    }
	public DateTime getStartDate() 
    {
        return startdate;
    }
	
    public DateTime getReturnDate()
    {
        return returndate;
    }
    
    public DateTime getEstimatedReturnDate() 
    {
        return est_returndate;
    }

    public void setReturnDate(DateTime estimatedReturnDate) 
    {
        returndate = estimatedReturnDate;
    }
   
    public float getRentalFee() 
    {
        return fee;
    }

    public void setRentalFee(float rentalFee) 
    {
        this.fee = rentalFee;
    }

    
    public void setStartdate(DateTime D) 
    {
        this.startdate = D;
    }
    public float getLateFee() 
    {
        return late_fee;
    }

    public void setLateFee(float lateFee) 
    {
        this.late_fee = lateFee;
    }

	public String getID() {
		return ID;
	}
	
	public String toString() {
  	  String output = Record_Id + ":" + startdate + ":" + returndate + ":" + fee + ":" + late_fee ;
  	  return output;
  	 }

	public String getDetails() {
		String s = toString();
    	return s;
	}
	public void setActualReturnDate(DateTime actualReturnDate) {
		  this.returndate = actualReturnDate;
		 }
	
		
}
