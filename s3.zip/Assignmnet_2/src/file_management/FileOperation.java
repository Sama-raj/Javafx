package file_management;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Rental_system.others_Controller.*;
import Rental_system.others_Controller.DateTime;
import Rental_system.others_Controller.Premium_suite;
import Rental_system.others_Controller.Rental_property;
import Rental_system.others_Controller.Rental_records;

public class FileOperation {
	
	private static DateTime getdate(String s)
	{
		int dd,mm,yyyy;
		DateTime date;
		dd = Integer.parseInt(s.substring(0, 2));
		mm = Integer.parseInt(s.substring(3, 5));
		yyyy = Integer.parseInt(s.substring(6, 10));
		date = new DateTime(dd,mm,yyyy);
		return date;
	}


		public static void writefileproperty(ArrayList<Rental_property> rP, String s) throws FileNotFoundException {
			PrintWriter writer =new PrintWriter(s);
	        
	    	for (int i = 0; i < rP.size(); i++)
	    	{
	    		   String a = rP.get(i).getDetails();
	    		   writer.println(a);
	        }

	    	writer.close();	
			
		}
		public static void writefilerecords(ArrayList<Rental_records> rP, String s) throws FileNotFoundException {
			PrintWriter writer =new PrintWriter(s);
	        //
	    	for (int i = 0; i <rP.size(); i++) 
	    	{
	    		   String a = rP.get(i).toString();
	    		   writer.println(a);
	        }

	    	writer.close();	
			
		}
		public static ArrayList<Rental_property> readfileproperty(File f) throws FileNotFoundException
		
		{	
			ArrayList<Rental_property> RP = new ArrayList<Rental_property>();
		try {
				BufferedReader input = new BufferedReader(new FileReader(f));
				
				
				String next = input.readLine();
				

				while (next != null) {
					String[] substring = next.split(":");
		        	

					if(substring[4].toLowerCase().equals("apartment"))
					{
					Rental_property P = new Apartment(substring[0],Integer.parseInt(substring[1]),
							substring[2],substring[3],Integer.parseInt(substring[5]),substring[4]);
					P.setPropertyStatus(substring[6]);
					P.setdesc(substring[8]);
					P.setimage(substring[7]);
					
					P.setlmdate(null);
					RP.add(P);
					}
					else if(substring[4].toLowerCase().equals("premiumsuite"))
					{
						DateTime date = getdate(substring[7]);
					Rental_property P = new Premium_suite(substring[0],Integer.parseInt(substring[1]),
								substring[2],substring[3],Integer.parseInt(substring[5]),substring[4],date);	
								P.setPropertyStatus(substring[6]);
								P.setdesc(substring[9]);
								P.setimage(substring[8]);
								RP.add(P);
					}
					else if(substring.length==6)
					{
						ArrayList<Rental_records> RR = new ArrayList<Rental_records>();

		        			
							DateTime startdate = getdate(substring[1]);
							DateTime returndate = getdate(substring[2]);
							int rentdays = DateTime.diffDays(returndate, startdate);
							Rental_records R = new Rental_records(substring[0],startdate,rentdays);
							R.setLateFee(Float.parseFloat(substring[5]));
							R.setRentalFee(Float.parseFloat(substring[4]));
		        			R.setReturnDate(getdate(substring[2]));
			                 R.setActualReturnDate(getdate(substring[3]));
		        		
		     
		        		for( int i = 0;i<RP.size();i++) {
		        			if (substring[0].startsWith(RP.get(i).getPropertyId())){
		        				RR.add(R);
		        				
		        			}
		        		
		        			
		        		}
		        			
		        		
		        		}
		        		
		        	
					
					else {		  next = input.readLine();
		}
				  
				  next = input.readLine();
				}
				input.close();

		} catch (Exception e) {
			System.err.println("File Reading Error!");
			
		}
		return RP;
		}
		
public static ArrayList<Rental_records> readfilerecords() throws FileNotFoundException
		
		{	File file = new File("RentalRecord.txt");
			ArrayList<Rental_records> RR = new ArrayList<Rental_records>();
		try {
				
			BufferedReader input = new BufferedReader(new FileReader(file));
			
			String next = input.readLine();
				

				while (next != null) {
					String[] substring = next.split(":");
                	String[] a = next.split(":");

					String[] ID = substring[0].split("-");
					DateTime startdate = getdate(substring[1]);
					DateTime returndate = getdate(substring[2]);
					int rentdays = DateTime.diffDays(returndate, startdate);
					Rental_records R = new Rental_records(ID[0],ID[1],startdate,rentdays);
					R.setLateFee(Integer.parseInt(substring[3]));
					R.setRentalFee(Integer.parseInt(substring[4]));
					RR.add(R) ; 
				  
					
				  System.out.println(next);
				  next = input.readLine();
				}
				input.close();

		} catch (Exception e) {
			System.err.println("File Reading Error!");
			System.exit(0);
		}
		return RR;
	    }
public static ArrayList<Rental_property> readfileproperty_firstrun() throws FileNotFoundException

{	
	File file = new File("alldetails.txt");
	ArrayList<Rental_property> RP = new ArrayList<Rental_property>();
try {
		BufferedReader input = new BufferedReader(new FileReader(file));
		
		
		String next = input.readLine();
		
		while (next != null) {
			String[] substring = next.split(":");
        	

			if(substring[4].toLowerCase().equals("apartment"))
			{
			Rental_property P = new Apartment(substring[0],Integer.parseInt(substring[1]),
					substring[2],substring[3],Integer.parseInt(substring[5]),substring[4]);
			P.setPropertyStatus(substring[6]);
			P.setdesc(substring[8]);
			P.setimage(substring[7]);
			
			P.setlmdate(null);
			RP.add(P);
			}
			else if(substring[4].toLowerCase().equals("premiumsuite"))
			{
				DateTime date = getdate(substring[7]);
			Rental_property P = new Premium_suite(substring[0],Integer.parseInt(substring[1]),
						substring[2],substring[3],Integer.parseInt(substring[5]),substring[4],date);	
						P.setPropertyStatus(substring[6]);
						P.setdesc(substring[9]);
						P.setimage(substring[8]);
						RP.add(P);
			}
			else if(substring.length==6)
			{
				ArrayList<Rental_records> RR = new ArrayList<Rental_records>();

        			
					DateTime startdate = getdate(substring[1]);
					DateTime returndate = getdate(substring[2]);
					int rentdays = DateTime.diffDays(returndate, startdate);
					Rental_records R = new Rental_records(substring[0],startdate,rentdays);
					R.setLateFee(Float.parseFloat(substring[5]));
					R.setRentalFee(Float.parseFloat(substring[4]));
        			R.setReturnDate(getdate(substring[2]));
	                 R.setActualReturnDate(getdate(substring[3]));
        		
     
        		for( int i = 0;i<RP.size();i++) {
        			if (substring[0].startsWith(RP.get(i).getPropertyId())){
        				RR.add(R);
        				
        			}
        		
        			
        		}
        			
        		
        		}
        		
        	
			
			else {		  next = input.readLine();
}
		  
		  next = input.readLine();
		}
		input.close();

} catch (Exception e) {
	System.err.println("File Reading Error!");
	
}
return RP;
}

public static void writefilerecords_append(ArrayList<Rental_records> rP, String s) throws IOException {
	FileWriter fw = null; BufferedWriter bw = null; PrintWriter pw = null;

	fw = new FileWriter(s, true); 
	bw = new BufferedWriter(fw);
	pw = new PrintWriter(bw);

	
    
	for (int i = 0; i <rP.size(); i++) 
	{
		   String a = rP.get(i).toString();
		   pw.println(a);
    }

	pw.close();	
	
}
}
		